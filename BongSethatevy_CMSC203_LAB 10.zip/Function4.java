//Implement the denominator of function #3 as function #4.  
//Run function #4 to estimate where the function goes to zero, which will of course make function #3 undefined.
public class Function4 extends Function {

	
	@Override
	public double fnValue(double x) {
		return (Math.pow(x, 3)-(7*Math.pow(x,2)) + 15*x-9);
		
	}

	public String toString() {
		return "x^3 - 7*x^2 + 15*x - 9";
	}

}
