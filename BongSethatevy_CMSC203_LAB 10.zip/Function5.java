//TASK #3 � Add a fifth function
//Very interesting behavior happens with the function f(x)=sin(1/x)
public class Function5 extends Function {

	@Override
	public double fnValue(double x) {
		if (x==0.0)
			return Double.MAX_VALUE;
		else
			return Math.sin(1/x);
	}
	
	public String toString() {
		return "sin(1/x)";
	}
}
